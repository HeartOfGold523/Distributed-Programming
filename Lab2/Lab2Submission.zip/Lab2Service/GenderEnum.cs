﻿using System.Runtime.Serialization;

namespace Lab2Service
{
    public enum GenderEnum
    {
        [EnumMember] Unknown,
        [EnumMember] Male,
        [EnumMember] Female
    }
}